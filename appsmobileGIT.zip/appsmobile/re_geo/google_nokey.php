<?php
$str=file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?latlng='.$_POST['latlng'].'&sensor=false');
$str_json=stripslashes($str);
$js=json_decode($str_json,true);
echo $js['results'][0]['formatted_address'];
?>