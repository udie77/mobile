<?php
$str=file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?latlng='.$_POST['latlng'].'&sensor=true&key=AIzaSyD6U5rbjTlzuXUokoWhwvrPOP4-3wwK_p8');
$str_json=stripslashes($str);
$js=json_decode($str_json,true);
echo $js['results'][0]['formatted_address'];
?>