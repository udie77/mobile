<?php
$latlng=explode(",",$_POST['latlng']);
$str=file_get_contents('http://nominatim.openstreetmap.org/search?q='.$latlng[0].'%2C'.$latlng[1].'&format=json');
$str_json=stripslashes($str);
$js=json_decode($str_json,true);
echo $js[0]['display_name'];
?>