<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mmain extends CI_Model {

	

	public function get_list($id){
		$id = $this->session->userdata('id');
		$query="SELECT devices.name,devices.id as 'id_dev',positions.id,positions.address, positions.latitude,positions.longitude,positions.time,positions.speed,positions.course,positions.other, detail_devices.gsm, users.login FROM devices, positions, users_devices,detail_devices,users WHERE  users_devices.devices_id = devices.id AND users_devices.users_id = users.id AND devices.id = detail_devices.device_id AND devices.latestPosition_id = positions.id AND users.id = '$id' ORDER BY devices.name "; 
		$result=$this->db->query($query);
		return $result->result();
	}

	public function get_list2($id){
		$query="SELECT devices.name,devices.id as 'id_dev',positions.id,positions.address, positions.latitude,positions.longitude,positions.time,positions.speed,positions.course,positions.other,positions.odometer,positions.last_alarm,positions.time_alarm, detail_devices.gsm, users.login FROM devices, positions, users_devices,detail_devices,users WHERE  users_devices.devices_id = devices.id AND users_devices.users_id = users.id AND devices.id = detail_devices.device_id AND devices.latestPosition_id = positions.id AND users.id = '$id' ORDER BY devices.name "; 
		$result=$this->db->query($query);
		$data = $result->result();
		$json= array();
		 foreach ($data as $list) {
		 	$row = array();
		 	$id = $list->id;
		 	$row[]=$list->name;
		 	$time = date_create($list->time);
		 	$row[]=date_format($time, "d M Y, H:i:s");
		 	$spit = $list->speed;
		 	$row[]=sprintf("%1.2f", $spit*1.85002);
		 	$lats = $list->latitude;
		 	$lons = $list->longitude;
		 	$addr = "";
		 	$alamat=$list->address;
		 	$acc = "No Data";
		 	$xml = simplexml_load_string($list->other);
				foreach($xml as $k => $v){
									
				   if(strtolower(trim($k))=="acc"){
					   
					   if($v=="true"){
						     $acc="ON";
					   }else{
						   $acc="OFF";
					   }
				   }
				}
			$alarm_val = $list->last_alarm;
			$jns_alarm = "Normal";
			$date_alarm="-";
			if ($alarm_val) {

				$d_alarm = date_create($list->time_alarm);
				$cek_date = date_format($d_alarm, "Y-m-d");
				$d_now = date_create();
				$now = date_format($d_now, "Y-m-d");
				if ($now == $cek_date) {
					$date_alarm = date_format($d_alarm, "H:i:s");
					$date_alarm = $date_alarm." WIB";

					if ($alarm_val == 1) {
						$jns_alarm = "Shock ALarm";
					}elseif ($alarm_val == 2) {
						$jns_alarm = "Power Cut Alarm";
					}elseif ($alarm_val == 3) {
						$jns_alarm = "Low Battery Alarm";
					}elseif ($alarm_val == 4) {
						$jns_alarm = "SOS Alarm";
					}
				}
						
			}
			
		 	$row[]= $addr;
		 	$row[]= $lats;
		 	$row[]= $lons;
		 	$row[]= $list->id_dev;
		 	$row[]= $acc;
		 	$row[]= $jns_alarm;
		 	$row[]= $date_alarm;

		 	$json[]=$row;
		 }
		 $to_encode["list"] = $json;
		return $to_encode;
	}

	public function google_key($lat,$lon){

		$kord = $lat.",".$lon;
		$nulla = "";
		$str=file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?latlng='.$kord.'&sensor=true&key=AIzaSyD6U5rbjTlzuXUokoWhwvrPOP4-3wwK_p8');
		$str_json=stripslashes($str);
		$js=json_decode($str_json,true);
		$status=$js['status'];
		if ($status == "OK"){
			return $js['results'][0]['formatted_address'];
		}else {
		return $nulla;
		}
	}

	public function google_nokey($lat,$lon){
		
		$kord = $lat.",".$lon;
		$str=file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?latlng='.$kord.'&sensor=false');
		$str_json=stripslashes($str);
		$js=json_decode($str_json,true);
		return $js['results'][0]['formatted_address'];

	}

	public function osm($lat,$lon){
		
		// $latlng=explode(",",$_POST['latlng']);
		$kord = $lat.",".$lon;
		$str=file_get_contents('http://nominatim.openstreetmap.org/search?q='.$kord.'&format=json');
		$str_json=stripslashes($str);
		$js=json_decode($str_json,true);
		return $js[0]['display_name'];

	}

	public function save_address($alamat,$id_pos){
		$data = array(
               'address' => $alamat
            );

		$this->db->where('id', $id_pos);
		$this->db->update('positions', $data);
	}


	public function get_data_by_posid($id_pos){

		$query="SELECT a.latitude, a.longitude, a.speed, a.address, a.course, a.other, a.time, a.device_id, b.name FROM positions a INNER JOIN devices b ON a.`device_id`= b.`id` WHERE a.id = '$id_pos'"; 
		$result=$this->db->query($query);
		return $result->result_array();

	}

	public function get_data_by_devid($id_dev){

		$query="SELECT a.id as 'id_dev', a.name, b.* FROM devices a INNER JOIN positions b ON a.`latestPosition_id` = b.`id` WHERE a.`id` = '$id_dev'"; 
		$result=$this->db->query($query);
		$data = $result->result();
		$json= array();
		 foreach ($data as $list) {
		 	$row = array();
		 	$id = $list->id;
		 	$row[]=$list->name;
		 	$time = date_create($list->time);
		 	$row[]=date_format($time, "d M Y, H:i:s");
		 	$spit = $list->speed;
		 	$row[]=sprintf("%1.2f", $spit*1.85002);
		 	$lats = $list->latitude;
		 	$lons = $list->longitude;
		 	$addr = "";
		 	$alamat=$list->address;
		 	if ($alamat == null || $alamat == "") {
		 		$get_addr = $this->google_key($lats,$lons);

		 		if ($get_addr!=""){

		 			$addr = $get_addr;
		 			$this->main->save_address($get_addr,$id);

		 		}else{

		 			$get_addr2 = $this->google_nokey($lats,$lons);

		 			if ($get_addr2!="") {

		 				$addr = $get_addr2;
		 				$this->main->save_address($get_addr2,$id);
		 				# code...
		 			} else {
		 				
		 				$get_addr3 = $this->osm($lats,$lons);

		 				if ($get_addr3!="") {

		 					$addr = $get_addr3;
		 					$this->main->save_address($get_addr3,$id);
		 					# code...
		 				} else {
		 					$addr = "Getting Address failed";
		 				}
		 				

		 			}
		 			
		 		}
		 	} else {
		 		$addr = $alamat;
		 	}
		 	
		 	$row[]= $addr;
		 	$row[]= $lats;
		 	$row[]= $lons;
		 	$row[]= $list->id_dev;
		 	$row[]= round($list->course);
		 	$acc = "";
		 	$sat = "";
		 	$xml = simplexml_load_string($list->other);
				foreach($xml as $k => $v){
									
				   if(strtolower(trim($k))=="acc"){
					   
					   if($v=="true"){
						     $acc="ON";
					   }else{
						   $acc="OFF";
					   }
				   }
				   
				
				   
				   if(strtolower(trim($k))=="satellites"){
					   
					   $sat=$v;
					 
				   }				   
				   
				 //    if(strtolower(trim($k))=="alarm"){
					// 	$nilai_alarm=$v;
					// }
				   
				 //   if(strtolower(trim($k))=="alarm_type"){
					//    if($v=="1"){
					// 	  if($nilai_alarm=="true"){
					// 		  $alarm_ket="Shock Alarm";  
					// 	  } 
					//    }
					//    else if($v=="2"){
					// 	  if($nilai_alarm=="true"){
					// 		  $alarm_ket="Power Cut Alarm";  
					// 	  } 
					//    }
					//    else if($v=="3"){
					// 	  if($nilai_alarm=="true"){
					// 		  $alarm_ket="Low Battery Alarm";  
					// 	  } 
					//    }
					//    else if($v=="4"){
					// 	  if($nilai_alarm=="true"){
					// 		  $alarm_ket="SOS Alarm";  
					// 	  } 
					//    }
				 //   }
				   
				   
				}
		 	$row[]=$acc;
		 	$row[]=intval($sat);

		 	$json[]=$row;
		 }
		 $to_encode["list"] = $json;
		return $to_encode;
	}

}

/* End of file mmain.php */
/* Location: ./application/models/mmain.php */