<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mlogin extends CI_Model {

	public function cek_user($user,$pass,$ingat){

		$query="select * from users where login = '$user' and password = '$pass'"; 
		$result=$this->db->query($query);
		if($result->num_rows() == 0) 
		{
         // username dan password tsb tidak ada 
			return false;
		}
		else 
		{
         // ada, maka ambil informasi dari database
			$userdata = $result->row();
			$session_data = array(
				'username' => $userdata->login,
				'password' => $userdata->password,
				'id' => $userdata->id,
				'is_login' => true,
				);
         // buat session
			$server = $userdata->new_serve;

			if($ingat != 1)
			{
				$this->session->sess_expiration = '30';
			   $this->session->sess_expire_on_close = TRUE;

			}
			else
			{

			   $this->session->sess_expiration = '15778463';
			   $this->session->sess_expire_on_close = FALSE;
			}

			$this->session->set_userdata($session_data);
			$cek_server = "";
			if ($server == "1") {
				$cek_server = "baru";
			} else {
				$cek_server = "lama";
			}

			return $cek_server;
			
		}        
	}

	

}

/* End of file mlogin.php */
/* Location: ./application/models/mlogin.php */