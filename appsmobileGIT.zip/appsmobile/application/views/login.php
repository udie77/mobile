<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Mobile Apps | Army-Track</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" href="<?=base_url()?>/icon/favicon.ico" type="image/gif">
  <link rel="stylesheet" href="<?php echo base_url('asset/css/army-theme.css'); ?>" />
  <link rel="stylesheet" href="<?php echo base_url('asset/css/jquery.mobile.icons.min.css'); ?>" />
  <link rel="stylesheet" href="<?php echo base_url('asset/css/jquery.mobile.structure-1.4.5.css'); ?>" />
  <script src="<?php echo base_url(); ?>asset/js/jquery.js"></script>
  <script src="<?php echo base_url(); ?>asset/js/jquery.mobile-1.4.5.js"></script> 
  <script type="text/javascript">

    $(document).ready(function() {
      $( "#txtuser" ).focus();
  $("#showHide").click(function() {
    if ($(".password").attr("type") == "password") {
      $(".password").attr("type", "text");
      $("#showHideLabel").html("Hide Password");

    } else {
      $(".password").attr("type", "password");
      $("#showHideLabel").html("Show Password");
    }
  });
});

  </script>
</head>
<body>
	<div data-role="page" id="pageone" data-dialog="true" data-close-btn="none">
  <div data-role="header">
    <h1>Army Mobile</h1>
    
  </div>
  <center>
  <img src="<?php echo base_url('asset/img/bann_login.png'); ?>" alt="" width="250px" height="auto">
  </center>
  <div data-role="main" class="ui-content">
  <font color="red"><?php if($this->session->flashdata('erroralert')) {
    echo $this->session->flashdata('erroralert');
  } ?></font>
  <form action="<?php echo base_url()."clogin/log";?>" data-ajax="false" method="POST">
    <label for="txtuser">Username <?php echo form_error('txtuser'); ?></label>
<input type="text" name="txtuser" id="txtuser" value="<?php echo set_value('txtuser'); ?>">
<label for="txtpass">Password <?php echo form_error('txtpass'); ?></label>
<input type="password" name="txtpass" id="txtpass" class="password" value="<?php echo set_value('txtpass'); ?>" autocomplete="off">
<fieldset data-role="controlgroup" data-type="horizontal"  data-mini="true">
      <input type="checkbox" name="ingatsaya" id="checkbox-mini-0" value="1">
    <label for="checkbox-mini-0">Remember me</label>

<input type="checkbox" id="showHide"   />
      <label for="showHide" id="showHideLabel">Show Password</label></fieldset>
<br>
<button class="ui-btn ui-shadow ui-corner-all ui-btn-icon-right ui-icon-lock" type="submit">Login</button>
</form>
  </div>
  
  <div data-role="footer">
    <h1>&copy; Army Tracking Indonesia 2016</h1>
  </div>
</div>
</body>
</html>