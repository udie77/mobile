<script type="text/javascript">
$(document).on({
  ajaxStart: function() { 
    $.mobile.loading('show');
  },
  ajaxStop: function() {
    $.mobile.loading('hide');
  }    
});

	 $(document).ready(function() {

	 	$.ajax({
        url : "<?php echo base_url('cmain/ajax_list/')?>",
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {
           var items="";  
   //          $.each(data, function(i, item) {
			//     // items += '<li><a href=/"#/"><p style=/"margin-top:15px;/"><strong>'+data[i].name+'</strong></p><p>'+data[i].time+' WIB <br>'+data[i].name+'Kmh<br>'+data[i].address+'</p></a></li>';
   //              items += "<li>"+data[i].name+"</li>";
			// });​

            $.each(data.list, function(index,data) {        
                items+="<li><a href='#'><p style='margin-top:15px;'><strong>"+data.name+"</strong></p><p>"+data.time+" WIB <br>"+data.speed+"Kmh<br>"+data.address+"</p></a></li>";
            });
            // $.mobile.showPageLoadingMsg();
			$('#listview1').html(items);
			$('#listview1').listview().listview('refresh');
            
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });

	 });

</script>