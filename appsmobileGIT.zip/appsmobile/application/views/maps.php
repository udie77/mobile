<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Mobile Apps | Army-Track</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?php echo base_url('asset/css/army-theme.css'); ?>" />
  <link rel="stylesheet" href="<?php echo base_url('asset/css/jquery.mobile.icons-1.4.5.css'); ?>" />
  <link rel="stylesheet" href="<?php echo base_url('asset/css/jquery.mobile.structure-1.4.5.css'); ?>" />
  <script src="http://maps.google.com/maps/api/js" type="text/javascript"></script>
  <script src="<?php echo base_url(); ?>asset/js/jquery.js"></script>
  <script src="<?php echo base_url(); ?>asset/js/jquery.mobile-1.4.5.js"></script>
  <script src="<?php echo base_url(); ?>asset/js/gmaps.js"></script>

  <style type="text/css" media="screen">

          #content {
            padding: 0 !important;
        }


          .overlay{
        display:block;
        text-align:center;
        color:#fff;
        font-size:14px;
        opacity:0.8;
        background:#4477aa;
        border:solid 3px #336699;
        border-radius:4px;
        box-shadow:2px 2px 10px #333;
        text-shadow:1px 1px 1px #666;
        padding:0 2px;
      }
      .overlay_green{
        display:block;
        text-align:center;
        color:#fff;
        font-size:14px;
        opacity:0.8;
        background:#008000;
        border:solid 3px #005900;
        border-radius:4px;
        box-shadow:2px 2px 10px #333;
        text-shadow:1px 1px 1px #666;
        padding:0 2px;
      }

      .overlay_red{
        display:block;
        text-align:center;
        color:#fff;
        font-size:14px;
        opacity:0.8;
        background:#e50000;
        border:solid 3px #990000;
        border-radius:4px;
        box-shadow:2px 2px 10px #333;
        text-shadow:1px 1px 1px #666;
        padding:0 2px;
      }

      .overlay_arrow{
        left:50%;
        margin-left:-16px;
        width:0;
        height:0;
        position:absolute;
      }
      .overlay_arrow.above{
        bottom:-15px;
        border-left:16px solid transparent;
        border-right:16px solid transparent;
        border-top:16px solid #336699;
      }
      .overlay_arrow.below{
        top:-15px;
        border-left:16px solid transparent;
        border-right:16px solid transparent;
        border-bottom:16px solid #336699;
      }
    
  </style>
</head>

<body>
<!-- Start of first page -->
<div id="map-page" data-url="map-page">

	<div data-role="header" data-position="fixed">
    <a href="#" class="ui-btn ui-btn-left ui-shadow ui-corner-all ui-icon-carat-l ui-btn-icon-left" data-rel="back">Back</a>
		<!-- <h1><?php echo $data[0]['name']; ?></h1> -->
    <h1 id="judul"></h1>
	</div><!-- /header -->

	<div role="content" class="ui-content" id="content">
		<div id="map-canvas" style="height:100%"></div>
	</div><!-- /content -->

	<div data-role="footer" data-position="fixed" style="text-align:center;" data-tap-toggle="false">
	    <!-- <div data-role="navbar"  data-type="horizontal">
      <a href="#" id="track-car" onclick="toggle();" class="ui-btn ui-corner-all ui-shadow ui-icon-navigation ui-btn-icon-left">Track with car</a>
      <a href="#" id="track-bike" onclick="toggle();" class="ui-btn ui-corner-all ui-shadow ui-icon-navigation ui-btn-icon-left">Track with bike</a>
    </div> -->
    <h4>&copy; Army Track Mobile Apps</h4>
	</div><!-- /footer -->
</div><!-- /page -->
<script type="text/javascript">
var map,overlay,marker;

var RotateIcon = function(options){
    this.options = options || {};
    this.rImg = options.img || new Image();
    this.rImg.src = this.rImg.src || this.options.url || '';
    this.options.width = this.options.width || this.rImg.width || 52;
    this.options.height = this.options.height || this.rImg.height || 60;
    canvas = document.createElement("canvas");
    canvas.width = this.options.width;
    canvas.height = this.options.height;
    this.context = canvas.getContext("2d");
    this.canvas = canvas;
};
RotateIcon.makeIcon = function(url) {
    return new RotateIcon({url: url});
};
RotateIcon.prototype.setRotation = function(options){
    var canvas = this.context,
        angle = options.deg ? options.deg * Math.PI / 180:
            options.rad,
        centerX = this.options.width/2,
        centerY = this.options.height/2;

    canvas.clearRect(0, 0, this.options.width, this.options.height);
    canvas.save();
    canvas.translate(centerX, centerY);
    canvas.rotate(angle);
    canvas.translate(-centerX, -centerY);
    canvas.drawImage(this.rImg, 0, 0);
    canvas.restore();
    return this;
};
RotateIcon.prototype.getUrl = function(){
    return this.canvas.toDataURL('image/png');
};

function getRealContentHeight() {
            var header = $.mobile.activePage.find("div[data-role='header']:visible");
            var footer = $.mobile.activePage.find("div[data-role='footer']:visible");
            var content = $.mobile.activePage.find("div[data-role='content']:visible:visible");
            var viewport_height = $(window).height();
 
            var content_height = viewport_height - header.outerHeight() - footer.outerHeight();
            if((content.outerHeight() - header.outerHeight() - footer.outerHeight()) <= viewport_height) {
                content_height -= (content.outerHeight() - content.height());
            } 
            return content_height;
        }




    $(document).ready(function(){

      $('#content').height(getRealContentHeight());
      
      map = new GMaps({
        el: '#map-canvas',
        lat: -6.330664,
        lng: 106.965966,
        zoomControl : true,
        zoomControlOpt: {
            style : 'LARGE',
            position: 'TOP_LEFT'
        },
        panControl : false,
        streetViewControl : true,
        mapTypeControl: true,
        overviewMapControl: false
      });

       $(document).on({
      ajaxStart: function() { 
        $.mobile.loading('show');
      },
      ajaxStop: function() {
        $.mobile.loading('hide');
      }    
    });

        load_list();
      
    });

    $(window).resize(function() {
      $('#content').height(getRealContentHeight());
          var lat = map.getCenter().lat(),
              lng = map.getCenter().lng();
          map.refresh();
          map.setCenter(lat, lng);
      });

  // function toggle()
  //   {

  //         if($("#track-car").hasClass("ui-btn-active")){

  //          kejar("driving");

  //        }else{
  //          kejar("walking");
  //        }

  //   }

  //   function kejar(kendaraan){

  //     

  //   }

    function load_list() {

        if(marker){
          map.removeMarker(marker);
        }

        if(overlay){
          map.removeOverlay(overlay);
        }

          $.ajax({
            url : "<?php echo base_url().'cmaps/ajax_maps/'.$data;?>",
            type: "GET",
            dataType: "JSON",
            success: function(data)
            {
              var lat,lon,raw_acc,acc,cssacc;
            
                $.each(data.list, function(index,data) {
                   lat = data[4];
                  lon = data[5];
                  raw_acc = data[8];
                  if (!raw_acc) {
                    acc = "Not detected";
                  }else{
                    acc = raw_acc;
                  };

            marker = map.addMarker({
                    lat: lat,
                    lng: lon,
                    title: data[0],
                     icon: {
                       url : '<?php echo base_url(); ?>asset/img/markers/green_'+data[7]+'.png'
                    
                      },
                    infoWindow: {
                      content: '<b>'+data[0]+'</b><br><p>Last Update: '+data[1]+' WIB<br>Coordinates: '+lat+', '+lon+'<br>Speed: '+data[2]+' Km/h<br>Engine: '+acc+'<br>GPS Signal: '+data[9]+' Satellites<br>Address: '+data[3]+'</p>'
                    }
                  });

                  var full_nopol = data[0];
                  var nopol =full_nopol.substring(full_nopol.lastIndexOf("(")+1,full_nopol.lastIndexOf(")"));
                  var jenis =full_nopol.substring(full_nopol.lastIndexOf(")")+1);
                  $('#judul').html(jenis);
                  if (data[2] > 3) {
                    cssacc="green";
                  }else{
                    cssacc="red";
                  };

                 overlay = map.drawOverlay({
                        lat: lat,
                        lng: lon,
                        content: '<div class="overlay_'+cssacc+'">'+nopol+'</div>',
                        verticalAlign: 'bottom',
                        horizontalAlign: 'center'
                      });
                  });

                map.setCenter(lat, lon);
                        
            },
            complete: function(data) {
            // Schedule the next request when the current one's complete
            setTimeout(load_list, 30000);
            

            //       GMaps.geolocate({
            //   success: function(position){
            //     // map.setCenter(position.coords.latitude, position.coords.longitude);
            //         map.addMarker({
            //        lat: position.coords.latitude,
            //         lng: position.coords.longitude,
            //         title: 'Your Location',
            //          icon: '<?php echo base_url(); ?>/asset/img/green_0.png',
            //         infoWindow: {
            //           content: '<p>Your Location</p>'
            //         }
            //       });
            //   map.renderRoute({
            //       origin: [position.coords.latitude, position.coords.longitude],
            //       destination: [data.list[4], data.list[5]],
            //       travelMode: 'driving',
            //       strokeColor: '#4477aa',
            //       strokeOpacity: 1,
            //       strokeWeight: 6
            //     }, {
            //       suppressMarkers: true,
            //       avoidHighways:true,
            //     });
            //   },
            //   error: function(error){
            //     alert('Geolocation failed: ' + error.message);
            //   },
            //   not_supported: function(){
            //     alert("Your browser does not support geolocation");
            //   }
            // });

          },
            error: function (jqXHR, textStatus, errorThrown)
            {
                clearTimeout(timeout);
                window.location.href="<?php echo base_url(); ?>clogin/logout";
            }
        });

    }

   // $(document).ready(function() {

   //     
    

   // });
</script>

</body>
</html>