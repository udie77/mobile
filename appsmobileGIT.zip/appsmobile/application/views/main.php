<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Mobile Apps | Army-Track</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?php echo base_url('asset/css/army-theme.css'); ?>" />
  <link rel="stylesheet" href="<?php echo base_url('asset/css/jquery.mobile.icons-1.4.5.css'); ?>" />
  <link rel="stylesheet" href="<?php echo base_url('asset/css/jquery.mobile.structure-1.4.5.css'); ?>" />
  
 
</head>

<body>
<!-- Start of first page -->
<div data-role="page" id="main" >

	<div data-role="header" data-position="fixed">
		<h1 style="text-align:left; margin-left:10px;">Hi, <?php echo ucfirst($this->session->userdata('username')); ?></h1>
		<button id="logout" class="ui-btn ui-btn-right ui-shadow ui-corner-all ui-icon-power ui-btn-icon-right">Logout</button>
		<!-- <a href="#" onclick="clear();" class="ui-btn-right ui-btn ui-btn-inline ui-mini ui-corner-all ui-btn-icon-right ui-icon-action">Logout</a> -->
	</div><!-- /header -->

	<div role="main" class="ui-content">
		<ul data-role="listview" data-filter="true" data-filter-placeholder="Cari Nopol..." id="listview1">
			
		</ul>
		
	</div><!-- /content -->

	<div data-role="footer" data-position="fixed">
		<h4>&copy; Army Track Mobile Apps</h4>
	</div><!-- /footer -->
</div><!-- /page -->
<script src="<?php echo base_url(); ?>asset/js/jquery.js"></script>
  <script src="<?php echo base_url(); ?>asset/js/jquery.mobile-1.4.5.js"></script> 
  <script type="text/javascript">

  	function load_list() {

		  		$.ajax({
		        url : "<?php echo base_url('cmain/ajax_list/')?>",
		        type: "GET",
		        dataType: "JSON",
		        success: function(data)
		        {
		           var items="";
		           var alamat = "";
		            $.each(data.list, function(index,data) {

		            	items+="<li><a data-ajax='false' href='<?php echo base_url(); ?>cmain/sendmaps/"+data[6]+"'><p style='margin-top:15px;'><strong>"+data[0]+"</strong></p><p>"+data[1]+" WIB <br>"+data[2]+" Kmh | Engine "+data[7]+"<br>Alarm: "+data[8]+", Time: "+data[9]+"</p></a></li>";

		                                      

		            });
		            // $.mobile.showPageLoadingMsg();
					$('#listview1').html(items);
					$('#listview1').listview().listview('refresh');
		            
		        },
		        complete: function() {
			      // Schedule the next request when the current one's complete
			      // setTimeout(load_list, 30000);
			      timeout = setTimeout(load_list, 120000);
			    },
		        error: function (jqXHR, textStatus, errorThrown)
		        {
		           // clearTimeout(timeout);
      				//window.location.href="<?php echo base_url(); ?>clogin/logout";
      				alert(textStatus);
		        }
		    });

  	}

  	
var timeout;
	 $(document).ready(function() {

	 	$('#logout').on('click',function(){
       //Place code here
       clearTimeout(timeout);
      window.location.href="<?php echo base_url(); ?>clogin/logout";
    });


			 	$(document).on({
		  ajaxStart: function() { 
		    $.mobile.loading('show');
		  },
		  ajaxStop: function() {
		    $.mobile.loading('hide');
		  }    
		});

		// var update = setInterval(load_list, 5000);
	 	load_list();
	 	// var update = window.setInterval(load_list,5000);

	 });
</script>
</body>
</html>