<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Clogin extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		$this->load->library('form_validation');
		$this->load->model('mlogin','login');
	}

	public function index()
	{
		if($this->session->userdata('id') ==''):
            $this->load->view('login');
        else:
        	redirect('cmain');
        endif;
		
	}

	public function log()
	{
		$this->form_validation->set_error_delimiters('<font color="red">', '</font>');
		$this->form_validation->set_message('required', 'is required');
		$this->form_validation->set_rules('txtuser', 'Username', 'required');
		$this->form_validation->set_rules('txtpass', 'Password', 'required');
		if ($this->form_validation->run() == FALSE) {
			$this->load->view('login');
		} else {
			$user = $this->input->post('txtuser');
			$pass = $this->input->post('txtpass');
			$ingat = $this->input->post('ingatsaya');
			$cek = $this->login->cek_user($user, $pass, $ingat);
				if($cek == "lama"){

				redirect('cmain');
				}
				elseif ($cek == "baru") {
					redirect('cmain2');
				}
				else{

					$this->session->set_flashdata('erroralert','Login Failed, Please try again.');
					redirect('clogin');
				}
		}
	}

	public function logout()
    {
    	
        $this->session->sess_destroy();
        redirect('clogin');
    }

}



/* End of file clogin.php */
/* Location: ./application/controllers/clogin.php */