<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cmaps2 extends CI_Controller {

	public function __construct(){
		parent::__construct();
		 if($this->session->userdata('id') ==''):
             redirect('clogin');
         endif;
        
        $this->load->helper('url');
        $this->load->model('mmain2','main');
        // $this->load->model('admin/modeldak');
	}

	public function index()
	{
		if ($this->session->flashdata('mapsid')) {
			$data_content['data'] = $this->session->flashdata('mapsid');

			// echo "<pre>";
			// print_r($data_content);
			// echo "</pre>";

			$this->load->view('maps2',$data_content);

		} else {
			redirect('cmain2');
		}
	
	}

	public function ajax_maps($dev)
	{
		if($this->session->userdata('id') ==''):
            redirect('clogin');
        endif;	
		$data= $this->main->get_data_by_devid($dev);
		 
		echo json_encode($data);

		// echo "<pre>";
		// print_r($data);
		// echo "</pre>";

	}

}

/* End of file cmaps2.php */
/* Location: ./application/controllers/cmaps2.php */