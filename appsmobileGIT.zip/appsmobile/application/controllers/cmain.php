<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cmain extends CI_Controller {

	public function __construct(){
		parent::__construct();
		if($this->session->userdata('id') ==''):
            redirect('clogin');
        endif;
        $this->load->model('mmain','main');
        // $this->load->model('admin/modeldak');
	}

	public function index()
	{
		
		$this->load->view('main');
	}

	public function ajax_list()
	{
		if($this->session->userdata('id') ==''):
            redirect('clogin');
        endif;
		$sid = $this->session->userdata('id');
		 $data= $this->main->get_list2($sid);
		 
		 echo json_encode($data);
	}
	
	public function sendmaps($mapsid){
		$this->session->set_flashdata('mapsid',$mapsid);
					redirect('cmaps');
	}

}

/* End of file cmain.php */
/* Location: ./application/controllers/cmain.php */